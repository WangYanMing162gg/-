﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class jltd : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if(!IsPostBack)
        {
            if (Session["mid"] == null)
            {
                MessageBox.RunScript(this, "alert('请先登录！');  var index = parent.layer.getFrameIndex(window.name); parent.layer.close(index);");
                return;
            }


            if (DbHelperSQL.Exists("select count(*) from Jianli_throw where mid=" + Session["mid"].ToString() + " and joid=" + Request.QueryString["id"]))
            {
               
                MessageBox.RunScript(this, "alert('投递失败，您已经投递过该职位！');  var index = parent.layer.getFrameIndex(window.name); parent.layer.close(index);");
                return;
            }

            RadioButtonList1.DataSource =DbHelperSQL.Query("select * from jianli where  mid=" + Session["mid"].ToString());
            RadioButtonList1.DataTextField = "title";
            RadioButtonList1.DataValueField = "jid";
            RadioButtonList1.DataBind();

            if (RadioButtonList1.Items.Count == 0)
            {
                MessageBox.RunScript(this, "alert('请先创建简历！');  var index = parent.layer.getFrameIndex(window.name); parent.layer.close(index);");
                return;
            }

            RadioButtonList1.SelectedValue = DbHelperSQL.GetSingle("select jid from jianli where ismr=1 and  mid=" + Session["mid"].ToString()).ToString();

          
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (RadioButtonList1.SelectedIndex == -1)
        {
            MessageBox.Show(this, "请选择要投递的简历！");
            return;
        }
   

        //设置Sql
        StringBuilder strSql = new StringBuilder();
        strSql.Append(@"insert into Jianli_throw ( mid,joid,jid,addtime,flag ) ");
        strSql.Append(@" values (@mid,@joid,@jid,@addtime,@flag)");

        //设置参数
        SqlParameter[] parameters = new SqlParameter[] {
            new SqlParameter("@mid", SqlDbType.VarChar,50),
            new SqlParameter("@joid", SqlDbType.Int,4),
            new SqlParameter("@jid", SqlDbType.Int,4),
            new SqlParameter("@addtime", SqlDbType.DateTime,8),
            new SqlParameter("@flag", SqlDbType.VarChar,50)      };

        parameters[0].Value = Session["mid"].ToString();
        parameters[1].Value = Request.QueryString["id"];
        parameters[2].Value = RadioButtonList1.SelectedValue;
        parameters[3].Value = DateTime.Now;
        parameters[4].Value = "等待回复";

        //提交到数据库
        DbHelperSQL.ExecuteSql(strSql.ToString(), parameters);


        MessageBox.RunScript(this, "alert('恭喜您投递成功，请返回！');  var index = parent.layer.getFrameIndex(window.name); parent.layer.close(index);");
        return;
    }
}