using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.Data;
using System.Data.SqlClient;


public partial class user_Default  : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        
        if(!IsPostBack)
        {
             
            
            
            
            
        }
    }

        /// <summary>
    /// �޸�����
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void ButtonPass_Click(object sender, EventArgs e)
    {
        //�����û���ź�ԭ����õ��û���Ϣ
        SqlDataReader sdr = DbHelperSQL.ExecuteReader("select * from members where  lname='" + Session["lname"].ToString() + "' and pwd='" + txt_pwd1.Text + "'");

        //�ж�ԭ�����Ƿ���ȷ
        if (sdr.Read())
        {
            //����������
            DbHelperSQL.ExecuteSql("update members set pwd='" + txt_pwd2.Text + "' where lname='" + Session["lname"].ToString() + "'");
            MessageBox.Show(this, "�޸ĳɹ�!");

        }
        else
        {
            MessageBox.Show(this, "ԭ���벻��ȷ!");
        }
        sdr.Close();
    }



    
    
}
