using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.Data;
using System.Data.SqlClient;


public partial class user_MasterPage  : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["lname"] == null)
        {
            Page.ClientScript.RegisterStartupScript(this.GetType(), "alert", "<script>alert('����û�е�¼��'); location.href = '../default.aspx';</script>");
            return;
        }

        if(!IsPostBack)
        {
             
            
            
            
            
        }
    }

        /// <summary>
    /// �˳���¼
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void logLnk_Click(object sender, EventArgs e)
    {
        Session.Abandon();
        Response.Redirect("../default.aspx");
    }



    
    
}
