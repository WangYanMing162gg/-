using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.Data;
using System.Data.SqlClient;


public partial class user_Default  : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack && Session["mid"]!=null)
        {

            bind();
        }
    }

    /// <summary>
    /// �󶨼���Ͷ��
    /// </summary>
    private void bind()
    {
        string where = " where a.mid="+Session["mid"].ToString();

        GridView1.DataSource = DbHelperSQL.Query("select a.*,jname,title from jianli_throw a left join  jobs b on a.joid=b.jid left join jianli c on a.jid=c.jid " + where + " order by tid desc");
        GridView1.DataBind();

    }

    /// <summary>
    /// ��ҳ�¼�
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
        bind();
    }


}
