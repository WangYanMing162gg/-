using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.Data;
using System.Data.SqlClient;


public partial class user_Default  : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        
        if(!IsPostBack)
        {

            show();
            
            
            
        }
    }

        /// <summary>
    /// ��ʼ��
    /// </summary>
    protected void show()
    {
        StringBuilder strSql = new StringBuilder();
        strSql.Append(@"select * from members where lname='" + Session["lname"].ToString() + "'");

        //���ݱ�ŵõ���Ӧ�ļ�¼
        DataSet ds = DbHelperSQL.Query(strSql.ToString());
        if (ds.Tables[0].Rows.Count > 0)
        {
            txt_lname.Text = ds.Tables[0].Rows[0]["lname"].ToString();
            txt_name1.Text = ds.Tables[0].Rows[0]["name1"].ToString();
            rtsex.SelectedValue=ds.Tables[0].Rows[0]["sex"].ToString();
            txt_age.Text = ds.Tables[0].Rows[0]["age"].ToString();
            txt_no1.Text = ds.Tables[0].Rows[0]["no1"].ToString();
            txt_tel.Text = ds.Tables[0].Rows[0]["tel"].ToString();
            txt_email.Text = ds.Tables[0].Rows[0]["email"].ToString();
            Labelpic.Text = ds.Tables[0].Rows[0]["pic"].ToString();
            if (Labelpic.Text != "" && Labelpic.Text.Length > 3)
            {
               Imagepic.ImageUrl = "../uploads/" + Labelpic.Text;
               Imagepic.Visible = true;
             }
            
            ddlflag.SelectedValue = ds.Tables[0].Rows[0]["flag"].ToString();
        }
    }

    /// <summary>
    /// �޸ĸ�������
    /// </summary>
    protected void ButtonUpdate_Click(object sender, EventArgs e)
    {
        StringBuilder strSql = new StringBuilder();
        strSql.Append("update members set ");
        strSql.Append("name1 = @name1,");
        strSql.Append("sex = @sex,");
        strSql.Append("age = @age,");
        strSql.Append("no1 = @no1,");
        strSql.Append("tel = @tel,");
        strSql.Append("email = @email,");
        strSql.Append("pic = @pic,");
        strSql.Append("flag = @flag");
        strSql.Append("  where lname=@lname");

        //���ò���
        SqlParameter[] parameters = new SqlParameter[] {
                    new SqlParameter("@lname", SqlDbType.VarChar,50),
                    new SqlParameter("@name1", SqlDbType.VarChar,50),
                    new SqlParameter("@sex", SqlDbType.VarChar,50),
                    new SqlParameter("@age", SqlDbType.VarChar,30),
                    new SqlParameter("@no1", SqlDbType.VarChar,50),
                    new SqlParameter("@tel", SqlDbType.VarChar,30),
                    new SqlParameter("@email", SqlDbType.VarChar,100),
                    new SqlParameter("@pic", SqlDbType.VarChar,50) ,
                    new SqlParameter("@flag", SqlDbType.VarChar,50)  };
              parameters[0].Value =txt_lname.Text;
              parameters[1].Value = txt_name1.Text;
              parameters[2].Value =rtsex.SelectedValue;
              parameters[3].Value = txt_age.Text;
              parameters[4].Value = txt_no1.Text;
              parameters[5].Value = txt_tel.Text;
              parameters[6].Value = txt_email.Text;
        string addrpic =Labelpic.Text;
        if (filepic.HasFile)
        {
            string name = this.filepic.PostedFile.FileName;
            int i = name.LastIndexOf('.');
            string extname = name.Substring(i);

            if (extname.ToLower() != ".jpg" && extname.ToLower() != ".png" && extname.ToLower() != ".gif")
            {
                MessageBox.Show(this, "���ϴ���ȷ��ʽ�ĸ�����Ƭ��");
                return;
            }
            string filename = DateTime.Now.ToString("yyyyMMddhhmmssfff");
            string path = filename + extname;
            string savePath = Server.MapPath(@"..\uploads\" + filename + extname);
            filepic.PostedFile.SaveAs(savePath);
            addrpic = path;
        }      
        parameters[7].Value =addrpic;
        parameters[8].Value = ddlflag.SelectedValue;


        DbHelperSQL.ExecuteSql(strSql.ToString(), parameters);

        MessageBox.Show(this, "�����ɹ���");
    }



    
    
}
