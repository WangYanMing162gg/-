using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.Data;
using System.Data.SqlClient;


public partial class user_Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!IsPostBack)
        {
            if (Session["lname"] != null)
            {
                string sql = "";
                sql = "select * from members a  where mid=" +Session["mid"].ToString();
                //���ݱ�ŵõ���Ӧ�ļ�¼
                SqlDataReader sdr = DbHelperSQL.ExecuteReader(sql);
                if (sdr.Read())
                {
                   ltmid.Text = sdr["lname"].ToString();
                    if (sdr["pic"].ToString() != "" && sdr["pic"].ToString().Length > 3)
                    {
                        imgLogo.ImageUrl = "../uploads/" + sdr["pic"].ToString();
                    }
                    Literal1.Text = sdr["flag"].ToString();

                 
                }

            }





        }
    }





}
