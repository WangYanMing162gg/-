using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.Data;
using System.Data.SqlClient;


public partial class user_Default  : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!IsPostBack)
        {

            bind();
        }
    }

    /// <summary>
    /// �󶨼���
    /// </summary>
    private void bind()
    {
        string where = " where  mid="+Session["mid"].ToString();

        GridView1.DataSource = DbHelperSQL.Query("select * from jianli " + where + " order by jid desc");
        GridView1.DataBind();

    }

    /// <summary>
    /// ��ҳ�¼�
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
        bind();
    }

    /// <summary>
    /// ����
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        bind();
    }

    /// <summary>
    /// ɾ������
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void lnk_Click(object sender, EventArgs e)
    {
        LinkButton lk = (LinkButton)sender;

        //ɾ����Ӧ�ļ�¼
        DbHelperSQL.ExecuteSql(" delete from jianli where jid=" + lk.CommandName);

        //���°�����Դ
        bind();
    }


}
