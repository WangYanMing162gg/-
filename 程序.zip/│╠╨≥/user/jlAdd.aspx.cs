using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.Data;
using System.Data.SqlClient;


public partial class user_Default  : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        
        if(!IsPostBack)
        {

            object ob = DbHelperSQL.GetSingle("select count(*) from Jianli where mid=" + Session["mid"].ToString());

            int t = ob == null ? 0 : int.Parse(ob.ToString());

            if(t>=3)
            {
                MessageBox.ShowAndRedirect(this, "ÿ��ѧ�����ֻ�ܴ���3�ݼ�����", "jlList.aspx");
                return;
            }
            
        }
    }



    /// <summary>
    /// ���Ӽ���
    ///</summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnSave_Click(object sender, EventArgs e)
    {
        if (RadioButtonList1.SelectedValue == "1")
        {
            DbHelperSQL.ExecuteSql(" update Jianli set ismr=0 where mid=" + Session["mid"].ToString());
        }

        //����Sql
        StringBuilder strSql = new StringBuilder();
        strSql.Append(@"insert into Jianli ( title,studys,tc,pj,ismr,mid,gtime ) ");
        strSql.Append(@" values (@title,@studys,@tc,@pj,@ismr,@mid,@gtime)");

        //���ò���
        SqlParameter[] parameters = new SqlParameter[] {
            new SqlParameter("@title", SqlDbType.VarChar,50),
            new SqlParameter("@studys", SqlDbType.VarChar,1000),
            new SqlParameter("@tc", SqlDbType.VarChar,1000),
            new SqlParameter("@pj", SqlDbType.VarChar,1000),
            new SqlParameter("@ismr", SqlDbType.Int,4),
            new SqlParameter("@mid", SqlDbType.Int,4),
            new SqlParameter("@gtime", SqlDbType.DateTime,8)      };

        parameters[0].Value = txt_title.Text;
        parameters[1].Value = txt_studys.Text;
        parameters[2].Value = txt_tc.Text;
        parameters[3].Value = txt_pj.Text;
        parameters[4].Value = RadioButtonList1.SelectedValue; ;
        parameters[5].Value = Session["mid"].ToString();
        parameters[6].Value = DateTime.Now;

        //�ύ�����ݿ�
        DbHelperSQL.ExecuteSql(strSql.ToString(), parameters);


        MessageBox.ShowAndRedirect(this, "�����ɹ����뷵��!", "jlLIst.aspx");
    }


}
