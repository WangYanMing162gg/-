﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class user_person : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            //初始化个人用户
            chushi();
        }
    }

    /// <summary>
    /// 初始化个人用户
    ///</summary>
    protected void chushi()
    {
        //判断url传递的id是否为null
        if (Request.QueryString["id"] != null)
        {

            string sql = "";
            sql = "select * from jianli where jid=" + Request.QueryString["id"];
            //根据编号得到相应的记录
            SqlDataReader sdr = DbHelperSQL.ExecuteReader(sql);
            if (sdr.Read())
            {
                lbltitle.Text = sdr["title"].ToString();
                lblstudys.Text = sdr["studys"].ToString().Replace("\n", "<br>");
                lbltc.Text = sdr["tc"].ToString().Replace("\n", "<br>");
                lblpj.Text = sdr["pj"].ToString().Replace("\n", "<br>");
                ViewState["mid"] = sdr["mid"].ToString();
            }

            sql = "select a.* from members a  where mid=" + ViewState["mid"].ToString();
            //根据编号得到相应的记录
             sdr = DbHelperSQL.ExecuteReader(sql);
            if (sdr.Read())
            {
                lblname1.Text = sdr["name1"].ToString();
                lblsex.Text = sdr["sex"].ToString();
                lblage.Text = sdr["age"].ToString();
                lblno1.Text = sdr["no1"].ToString();
                lbltel.Text = sdr["tel"].ToString();
                lblemail.Text = sdr["email"].ToString();
                if (sdr["pic"].ToString() != "" && sdr["pic"].ToString().Length > 3)
                {
                    imgpic.ImageUrl = "../uploads/" + sdr["pic"].ToString();
                }
            }

        }
    }
}

