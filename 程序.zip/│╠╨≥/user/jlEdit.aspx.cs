using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.Data;
using System.Data.SqlClient;


public partial class user_Default  : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        
        if(!IsPostBack)
        {

            //��ʼ������
            chushi();
        }
    }

    /// <summary>
    /// ��ʼ������
    /// </summary>
    protected void chushi()
    {

        StringBuilder strSql = new StringBuilder();
        strSql.Append(@"select * from jianli where jid=" + Request.QueryString["id"]);

        //���ݱ�ŵõ���Ӧ�ļ�¼
        DataSet ds = DbHelperSQL.Query(strSql.ToString());
        if (ds.Tables[0].Rows.Count > 0)
        {
            txt_title.Text = ds.Tables[0].Rows[0]["title"].ToString();
            txt_studys.Text = ds.Tables[0].Rows[0]["studys"].ToString();
            txt_tc.Text = ds.Tables[0].Rows[0]["tc"].ToString();
            txt_pj.Text = ds.Tables[0].Rows[0]["pj"].ToString();
            RadioButtonList1.SelectedValue = ds.Tables[0].Rows[0]["ismr"].ToString();
        }
    }

    /// <summary>
    /// �༭����
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnSave_Click(object sender, EventArgs e)
    {
        if (RadioButtonList1.SelectedValue == "1")
        {
            DbHelperSQL.ExecuteSql(" update Jianli set ismr=0 where mid=" + Session["mid"].ToString());
        }

        //����   
        StringBuilder strSql = new StringBuilder();

        strSql.Append("update jianli set ");
        strSql.Append("title = @title,");
        strSql.Append("studys = @studys,");
        strSql.Append("tc = @tc,");
        strSql.Append("pj = @pj,");
        strSql.Append("ismr = @ismr");
        strSql.Append("  where jid=@jid");
        int jid = int.Parse(Request.QueryString["id"]);

        //���ò���
        SqlParameter[] parameters = new SqlParameter[] {
                    new SqlParameter("@jid", SqlDbType.Int,4),
                    new SqlParameter("@title", SqlDbType.VarChar,50),
                    new SqlParameter("@studys", SqlDbType.VarChar,1000),
                    new SqlParameter("@tc", SqlDbType.VarChar,1000),
                    new SqlParameter("@pj", SqlDbType.VarChar,1000),
                    new SqlParameter("@ismr", SqlDbType.Int,4) };
        parameters[0].Value = jid;
        parameters[1].Value = txt_title.Text;
        parameters[2].Value = txt_studys.Text;
        parameters[3].Value = txt_tc.Text;
        parameters[4].Value = txt_pj.Text;
        parameters[5].Value = RadioButtonList1.SelectedValue;

        //�ύ�����ݿ�
        DbHelperSQL.ExecuteSql(strSql.ToString(), parameters);

        MessageBox.ShowAndRedirect(this, "�����ɹ����뷵��!", "jlList.aspx");
    }


}
