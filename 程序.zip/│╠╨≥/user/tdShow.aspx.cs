using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.Data;
using System.Data.SqlClient;


public partial class user_Default  : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            //��ʼ������Ͷ��
            chushi();
        }
    }

    /// <summary>
    /// ��ʼ������Ͷ��
    ///</summary>
    protected void chushi()
    {
        //�ж�url���ݵ�id�Ƿ�Ϊnull
        if (Request.QueryString["id"] != null)
        {

            string sql = "";
            sql = "select a.*,jname,title,people,money1 from jianli_throw a left join  jobs b on a.joid=b.jid left join jianli c on a.jid=c.jid  where a.tid=" + Request.QueryString["id"];
            //���ݱ�ŵõ���Ӧ�ļ�¼
            SqlDataReader sdr = DbHelperSQL.ExecuteReader(sql);
            if (sdr.Read())
            {
                lbltid.Text = sdr["tid"].ToString();
                lblmid.Text = sdr["mid"].ToString();
                lbljoid.Text = sdr["jname"].ToString();
                lblpeople.Text = sdr["people"].ToString();
                lblmoney1.Text = sdr["money1"].ToString();
                lbljid.Text = sdr["title"].ToString();
                lbladdtime.Text = sdr["addtime"].ToString();
                lblflag.Text = sdr["flag"].ToString();
                lblmemo.Text = sdr["memo"].ToString();
                lblantime.Text = sdr["antime"].ToString();
            }

        }
    }
}

