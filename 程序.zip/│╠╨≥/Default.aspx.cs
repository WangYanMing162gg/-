using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.Data;
using System.Data.SqlClient;


public partial class _Default  : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        
        if(!IsPostBack)
        {
             
            
            
            
            bind();
        }
    }

    
    /// <summary>
    /// ������
    /// </summary>
    protected void bind()
    {
        Repeater1.DataSource = DbHelperSQL.Query("select top 8 * from companys order by cid desc ");
        Repeater1.DataBind();



        GridView1.DataSource = DbHelperSQL.Query("select top 10 a.*,b.cname from jobs a  left join companys b on a.cid=b.cid  order by jid desc");
        GridView1.DataBind();

    }



    
    
}
