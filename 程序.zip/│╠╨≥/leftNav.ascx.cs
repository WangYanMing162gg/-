using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.Data;
using System.Data.SqlClient;


public partial class leftNav : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!IsPostBack)
        {




            bind();
        }
    }


    /// <summary>
    /// ������
    /// </summary>
    protected void bind()
    {
        Repeater1.DataSource = DbHelperSQL.Query("select top 10 * from jobs  a left join(select joid,count(*) as tt from jianli_throw group by joid) b on a.jid=b.joid  order by tt desc ");
        Repeater1.DataBind();



    }

    /// <summary>
    /// ��¼
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void ButtonLogin_Click(object sender, EventArgs e)
    {
        if (txt_lname.Text == "")
        {
            Page.ClientScript.RegisterStartupScript(this.GetType(), "alert", "<script>alert('�������û�����');</script>");
            return;
        }

        if (txt_pwd.Text == "")
        {
            Page.ClientScript.RegisterStartupScript(this.GetType(), "alert", "<script>alert('���������룡');</script>");
            return;
        }

        //�����û���������õ��û���Ϣ
        //�����û���������õ��û���Ϣ
        StringBuilder strSql = new StringBuilder();
        strSql.Append(@" select * from members ");
        strSql.Append(@" where lname=@lname and pwd=@pwd  ");

        //���ò���
        SqlParameter[] parameters = new SqlParameter[] {
            new SqlParameter("@lname", SqlDbType.VarChar,50),
            new SqlParameter("@pwd", SqlDbType.VarChar,50)     };

        parameters[0].Value = txt_lname.Text;
        parameters[1].Value = txt_pwd.Text;

        //�����û���������õ��û���Ϣ
        SqlDataReader sdr = DbHelperSQL.ExecuteReader(strSql.ToString(), parameters);

        //�ж��û��Ƿ����
        if (sdr.Read())
        {
            Session["mid"] = sdr["mid"].ToString();
            Session["lname"] = sdr["lname"].ToString();
            Response.Redirect(Request.Url.ToString());

        }
        else
        {
            Page.ClientScript.RegisterStartupScript(this.GetType(), "alert", "<script>alert('��¼ʧ�ܣ��û������������');</script>");
        }
    }

    /// <summary>
    /// �˳���¼
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void logLnk_Click(object sender, EventArgs e)
    {
        Session.Abandon();
        Response.Redirect("default.aspx");
    }





}
