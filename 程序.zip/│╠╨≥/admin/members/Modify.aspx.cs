﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.Data.SqlClient;
using System.Data;

public partial class members_Edit : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            //初始化毕业生
            chushi();
        }
    }

    /// <summary>
    /// 初始化毕业生
    /// </summary>
    protected void chushi()
    {

        StringBuilder strSql = new StringBuilder();
        strSql.Append(@"select * from members where mid=" + Request.QueryString["id"] );

        //根据编号得到相应的记录
        DataSet ds = DbHelperSQL.Query(strSql.ToString());
        if (ds.Tables[0].Rows.Count > 0)
        {
            txt_lname.Text = ds.Tables[0].Rows[0]["lname"].ToString();
            txt_pwd.Text = ds.Tables[0].Rows[0]["pwd"].ToString();
            txt_name1.Text = ds.Tables[0].Rows[0]["name1"].ToString();
            rtsex.SelectedValue=ds.Tables[0].Rows[0]["sex"].ToString();
            txt_age.Text = ds.Tables[0].Rows[0]["age"].ToString();
            txt_no1.Text = ds.Tables[0].Rows[0]["no1"].ToString();
            txt_tel.Text = ds.Tables[0].Rows[0]["tel"].ToString();
            txt_email.Text = ds.Tables[0].Rows[0]["email"].ToString();
            Labelpic.Text = ds.Tables[0].Rows[0]["pic"].ToString();
            if (Labelpic.Text != "" && Labelpic.Text.Length > 3)
            {
               Imagepic.ImageUrl = "../../uploads/" + Labelpic.Text;
               Imagepic.Visible = true;
             }
        }
    }

    /// <summary>
    /// 编辑毕业生
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnSave_Click(object sender, EventArgs e)
    {
        //更新   
        StringBuilder strSql = new StringBuilder();

        strSql.Append("update members set ");
        strSql.Append("lname = @lname,");
        strSql.Append("pwd = @pwd,");
        strSql.Append("name1 = @name1,");
        strSql.Append("sex = @sex,");
        strSql.Append("age = @age,");
        strSql.Append("no1 = @no1,");
        strSql.Append("tel = @tel,");
        strSql.Append("email = @email,");
        strSql.Append("pic = @pic");
        strSql.Append("  where mid=@mid");
        int mid = int.Parse(Request.QueryString["id"]);

        //设置参数
        SqlParameter[] parameters = new SqlParameter[] {
                    new SqlParameter("@mid", SqlDbType.Int,4),
                    new SqlParameter("@lname", SqlDbType.VarChar,50),
                    new SqlParameter("@pwd", SqlDbType.VarChar,30),
                    new SqlParameter("@name1", SqlDbType.VarChar,50),
                    new SqlParameter("@sex", SqlDbType.VarChar,50),
                    new SqlParameter("@age", SqlDbType.VarChar,30),
                    new SqlParameter("@no1", SqlDbType.VarChar,50),
                    new SqlParameter("@tel", SqlDbType.VarChar,30),
                    new SqlParameter("@email", SqlDbType.VarChar,100),
                    new SqlParameter("@pic", SqlDbType.VarChar,50)  };
              parameters[0].Value =mid;
              parameters[1].Value = txt_lname.Text;
              parameters[2].Value = txt_pwd.Text;
              parameters[3].Value = txt_name1.Text;
              parameters[4].Value =rtsex.SelectedValue;
              parameters[5].Value = txt_age.Text;
              parameters[6].Value = txt_no1.Text;
              parameters[7].Value = txt_tel.Text;
              parameters[8].Value = txt_email.Text;

        string addrpic =Labelpic.Text;
        if (fppic.HasFile)
        {
            string name = this.fppic.PostedFile.FileName;
            int i = name.LastIndexOf('.');
            string extname = name.Substring(i);
            string filename = DateTime.Now.ToString("yyyyMMddhhmmssfff");
            string path =  filename + extname;
            string savePath = Server.MapPath(@"..\..\uploads\" + filename + extname);
            fppic.PostedFile.SaveAs(savePath);
            addrpic = path;
        }
              parameters[9].Value =addrpic;

        //提交到数据库
        DbHelperSQL.ExecuteSql(strSql.ToString(), parameters);

        MessageBox.ShowAndRedirect(this, "操作成功，请返回!", "Manage.aspx");
    }



    
}

