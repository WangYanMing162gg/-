﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class jobs_Show : System.Web.UI.Page
{
  protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            //初始化职位
            chushi();
        }
    }

    /// <summary>
    /// 初始化职位
    ///</summary>
    protected void chushi()
    {
        //判断url传递的id是否为null
        if (Request.QueryString["id"] != null)
        {

            string sql="";
            sql="select a.*,b.cname from jobs a  left join companys b on a.cid=b.cid where jid="+ Request.QueryString["id"];
            //根据编号得到相应的记录
            SqlDataReader sdr = DbHelperSQL.ExecuteReader(sql);
            if (sdr.Read())
            {
                lbljid.Text = sdr["jid"].ToString();
                lbljname.Text = sdr["jname"].ToString();
                lblcid.Text = sdr["cname"].ToString();
                lblpeople.Text = sdr["people"].ToString();
                lblmoney1.Text = sdr["money1"].ToString();
                lblmemo.Text = sdr["memo"].ToString();
                lbladdtime.Text = sdr["addtime"].ToString();
            }

        }
    }
}

