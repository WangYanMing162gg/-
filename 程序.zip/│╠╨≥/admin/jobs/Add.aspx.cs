﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.Data.SqlClient;
using System.Data;

public partial class jobs_Add : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {


        }
    }

    /// <summary>
    /// 添加职位
    ///</summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnSave_Click(object sender, EventArgs e)
    {   
       //设置Sql
         StringBuilder strSql = new StringBuilder();
         strSql.Append(@"insert into Jobs ( jname,cid,people,money1,memo,addtime ) ");
        strSql.Append(@" values (@jname,@cid,@people,@money1,@memo,@addtime)");

        //设置参数
        SqlParameter[] parameters = new SqlParameter[] {
            new SqlParameter("@jname", SqlDbType.VarChar,50),
            new SqlParameter("@cid", SqlDbType.Int,4),
            new SqlParameter("@people", SqlDbType.VarChar,20),
            new SqlParameter("@money1", SqlDbType.VarChar,20),
            new SqlParameter("@memo", SqlDbType.NText,50000),
            new SqlParameter("@addtime", SqlDbType.DateTime,8)        };

        parameters[0].Value =txt_jname.Text;
        parameters[1].Value =Session["cid"].ToString();
        parameters[2].Value =txt_people.Text;
        parameters[3].Value =txt_money1.Text;
        parameters[4].Value =Textarea1.Value;
        parameters[5].Value =DateTime.Now;

        //提交到数据库
        DbHelperSQL.ExecuteSql(strSql.ToString(), parameters);


        MessageBox.ShowAndRedirect(this, "操作成功，请返回!", "Add.aspx");
    }

    
}

