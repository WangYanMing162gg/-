﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class jianli_throw_Show : System.Web.UI.Page
{
  protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            //初始化简历投递
            chushi();
        }
    }

    /// <summary>
    /// 初始化简历投递
    ///</summary>
    protected void chushi()
    {
        //判断url传递的id是否为null
        if (Request.QueryString["id"] != null)
        {

            string sql = "";
            sql = "select a.*,jname,title,people,money1 from jianli_throw a left join  jobs b on a.joid=b.jid left join jianli c on a.jid=c.jid  where a.tid=" + Request.QueryString["id"];
            //根据编号得到相应的记录
            SqlDataReader sdr = DbHelperSQL.ExecuteReader(sql);
            if (sdr.Read())
            {
                lbltid.Text = sdr["tid"].ToString();
                lblmid.Text = sdr["mid"].ToString();
                lbljoid.Text = sdr["jname"].ToString();
                lblpeople.Text = sdr["people"].ToString();
                lblmoney1.Text = sdr["money1"].ToString();
                lbljid.Text = sdr["title"].ToString();
                lbladdtime.Text = sdr["addtime"].ToString();
                lblflag.Text = sdr["flag"].ToString();
                lblmemo.Text = sdr["memo"].ToString();
                lblantime.Text = sdr["antime"].ToString();
            }

        }
    }
}

