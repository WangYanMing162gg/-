﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Text;

public partial class jianli_throw_Show : System.Web.UI.Page
{
  protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            //初始化简历投递
            chushi();
        }
    }

    /// <summary>
    /// 初始化简历投递
    ///</summary>
    protected void chushi()
    {
        //判断url传递的id是否为null
        if (Request.QueryString["id"] != null)
        {

            string sql = "";
            sql = "select a.*,jname,title,people,money1 from jianli_throw a left join  jobs b on a.joid=b.jid left join jianli c on a.jid=c.jid  where a.tid=" + Request.QueryString["id"];
            //根据编号得到相应的记录
            SqlDataReader sdr = DbHelperSQL.ExecuteReader(sql);
            if (sdr.Read())
            {
                lbltid.Text = sdr["tid"].ToString();
                lblmid.Text = sdr["mid"].ToString();
                lbljoid.Text = sdr["jname"].ToString();
                lblpeople.Text = sdr["people"].ToString();
                lblmoney1.Text = sdr["money1"].ToString();
                lbljid.Text = sdr["title"].ToString();
                lbladdtime.Text = sdr["addtime"].ToString();
            }

        }
    }
    
    protected void btnSave_Click(object sender, EventArgs e)
    {


        //更新   
        StringBuilder strSql = new StringBuilder();

        strSql.Append("update jianli_throw set ");  
        strSql.Append("flag = @flag,");
        strSql.Append("memo = @memo,antime=getdate() ");
        strSql.Append("  where tid=@tid");
        int tid = int.Parse(Request.QueryString["id"]);

        //设置参数
        SqlParameter[] parameters = new SqlParameter[] {
            new SqlParameter("@tid", SqlDbType.Int,4),               
            new SqlParameter("@flag", SqlDbType.VarChar,50),
            new SqlParameter("@memo", SqlDbType.VarChar,500)  };
        parameters[0].Value = tid;
        parameters[1].Value = RadioButtonList1.SelectedValue;
        parameters[2].Value = txt_memo.Text;

        //提交到数据库
        DbHelperSQL.ExecuteSql(strSql.ToString(), parameters);

        MessageBox.ShowAndRedirect(this, "操作成功，请返回!", "Manage.aspx");
    }
}

