﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class companys_Show : System.Web.UI.Page
{
  protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            //初始化企业
            chushi();
        }
    }

    /// <summary>
    /// 初始化企业
    ///</summary>
    protected void chushi()
    {
        //判断url传递的id是否为null
        if (Request.QueryString["id"] != null)
        {

            string sql="";
            sql="select * from companys where cid="+ Request.QueryString["id"];
            //根据编号得到相应的记录
            SqlDataReader sdr = DbHelperSQL.ExecuteReader(sql);
            if (sdr.Read())
            {
                lblcid.Text = sdr["cid"].ToString();
                lbllname.Text = sdr["lname"].ToString();
                lblpass.Text = sdr["pass"].ToString();
                lblcname.Text = sdr["cname"].ToString();
                lblctype.Text = sdr["ctype"].ToString();
                lblyg.Text = sdr["yg"].ToString();
                if (sdr["cgm"].ToString() != "" && sdr["cgm"].ToString().Length > 3)
                {
                    imgcgm.ImageUrl = "../../uploads/" + sdr["cgm"].ToString();
                }
                lblcdate.Text = sdr["cdate"].ToString();
                lbladdress.Text = sdr["address"].ToString();
                lbltel.Text = sdr["tel"].ToString();
                lblmemo.Text = sdr["memo"].ToString();
                lblregtime.Text = sdr["regtime"].ToString();
            }

        }
    }
}

