﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.Data.SqlClient;
using System.Data;

public partial class companys_Add : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
        
        }
    }

    /// <summary>
    /// 添加企业
    ///</summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnSave_Click(object sender, EventArgs e)
    {   
        //验证是否已经存在
        if (DbHelperSQL.Exists("select count(*) from companys where lname='" + txt_lname.Text + "'"))
        {
            MessageBox.Show(this, "该用户名已存在，请重新输入！");
            return;
        }

       //设置Sql
         StringBuilder strSql = new StringBuilder();
         strSql.Append(@"insert into Companys ( lname,pass,cname,ctype,yg,cgm,cdate,address,tel,memo,regtime ) ");
        strSql.Append(@" values (@lname,@pass,@cname,@ctype,@yg,@cgm,@cdate,@address,@tel,@memo,@regtime)");

        //设置参数
        SqlParameter[] parameters = new SqlParameter[] {
            new SqlParameter("@lname", SqlDbType.VarChar,50),
            new SqlParameter("@pass", SqlDbType.VarChar,50),
            new SqlParameter("@cname", SqlDbType.VarChar,50),
            new SqlParameter("@ctype", SqlDbType.VarChar,50),
            new SqlParameter("@yg", SqlDbType.VarChar,50),
            new SqlParameter("@cgm", SqlDbType.VarChar,50),
            new SqlParameter("@cdate", SqlDbType.VarChar,50),
            new SqlParameter("@address", SqlDbType.VarChar,100),
            new SqlParameter("@tel", SqlDbType.VarChar,50),
            new SqlParameter("@memo", SqlDbType.NText,50000),
            new SqlParameter("@regtime", SqlDbType.DateTime,8)        };

        parameters[0].Value =txt_lname.Text;
        parameters[1].Value =txt_pass.Text;
        parameters[2].Value =txt_cname.Text;
        parameters[3].Value =txt_ctype.Text;
        parameters[4].Value =txt_yg.Text;


        string addrcgm ="";
        if (fpcgm.HasFile)
        {
            string name = this.fpcgm.PostedFile.FileName;
            int i = name.LastIndexOf('.');
            string extname = name.Substring(i);
            string filename = DateTime.Now.ToString("yyyyMMddhhmmssfff");
            string path =  filename + extname;
            string savePath = Server.MapPath(@"..\..\uploads\" + filename + extname);
            fpcgm.PostedFile.SaveAs(savePath);
            addrcgm = path;
        }

        parameters[5].Value =addrcgm;
        parameters[6].Value =txt_cdate.Text;
        parameters[7].Value =txt_address.Text;
        parameters[8].Value =txt_tel.Text;
        parameters[9].Value =Textarea1.Value;
        parameters[10].Value =DateTime.Now;

        //提交到数据库
        DbHelperSQL.ExecuteSql(strSql.ToString(), parameters);


        MessageBox.ShowAndRedirect(this, "操作成功，请返回!", "Add.aspx");
    }

    
}

