﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.Data.SqlClient;
using System.Data;

public partial class companys_Edit : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            //初始化企业
            chushi();
        }
    }

    /// <summary>
    /// 初始化企业
    /// </summary>
    protected void chushi()
    {

        StringBuilder strSql = new StringBuilder();
        strSql.Append(@"select * from companys where cid=" + Request.QueryString["id"] );

        //根据编号得到相应的记录
        DataSet ds = DbHelperSQL.Query(strSql.ToString());
        if (ds.Tables[0].Rows.Count > 0)
        {
            txt_lname.Text = ds.Tables[0].Rows[0]["lname"].ToString();
            txt_pass.Text = ds.Tables[0].Rows[0]["pass"].ToString();
            txt_cname.Text = ds.Tables[0].Rows[0]["cname"].ToString();
            txt_ctype.Text = ds.Tables[0].Rows[0]["ctype"].ToString();
            txt_yg.Text = ds.Tables[0].Rows[0]["yg"].ToString();
            Labelcgm.Text = ds.Tables[0].Rows[0]["cgm"].ToString();
            if (Labelcgm.Text != "" && Labelcgm.Text.Length > 3)
            {
               Imagecgm.ImageUrl = "../../uploads/" + Labelcgm.Text;
               Imagecgm.Visible = true;
             }
            txt_cdate.Text = ds.Tables[0].Rows[0]["cdate"].ToString();
            txt_address.Text = ds.Tables[0].Rows[0]["address"].ToString();
            txt_tel.Text = ds.Tables[0].Rows[0]["tel"].ToString();
            Textarea1.Value = ds.Tables[0].Rows[0]["memo"].ToString();
        }
    }

    /// <summary>
    /// 编辑企业
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnSave_Click(object sender, EventArgs e)
    {
        //更新   
        StringBuilder strSql = new StringBuilder();

        strSql.Append("update companys set ");
        strSql.Append("lname = @lname,");
        strSql.Append("pass = @pass,");
        strSql.Append("cname = @cname,");
        strSql.Append("ctype = @ctype,");
        strSql.Append("yg = @yg,");
        strSql.Append("cgm = @cgm,");
        strSql.Append("cdate = @cdate,");
        strSql.Append("address = @address,");
        strSql.Append("tel = @tel,");
        strSql.Append("memo = @memo");
        strSql.Append("  where cid=@cid");
        int cid = int.Parse(Request.QueryString["id"]);

        //设置参数
        SqlParameter[] parameters = new SqlParameter[] {
                    new SqlParameter("@cid", SqlDbType.Int,4),
                    new SqlParameter("@lname", SqlDbType.VarChar,50),
                    new SqlParameter("@pass", SqlDbType.VarChar,50),
                    new SqlParameter("@cname", SqlDbType.VarChar,50),
                    new SqlParameter("@ctype", SqlDbType.VarChar,50),
                    new SqlParameter("@yg", SqlDbType.VarChar,50),
                    new SqlParameter("@cgm", SqlDbType.VarChar,50),
                    new SqlParameter("@cdate", SqlDbType.VarChar,50),
                    new SqlParameter("@address", SqlDbType.VarChar,100),
                    new SqlParameter("@tel", SqlDbType.VarChar,50),
                    new SqlParameter("@memo", SqlDbType.NText,50000)  };
              parameters[0].Value =cid;
              parameters[1].Value = txt_lname.Text;
              parameters[2].Value = txt_pass.Text;
              parameters[3].Value = txt_cname.Text;
              parameters[4].Value = txt_ctype.Text;
              parameters[5].Value = txt_yg.Text;

        string addrcgm =Labelcgm.Text;
        if (fpcgm.HasFile)
        {
            string name = this.fpcgm.PostedFile.FileName;
            int i = name.LastIndexOf('.');
            string extname = name.Substring(i);
            string filename = DateTime.Now.ToString("yyyyMMddhhmmssfff");
            string path =  filename + extname;
            string savePath = Server.MapPath(@"..\..\uploads\" + filename + extname);
            fpcgm.PostedFile.SaveAs(savePath);
            addrcgm = path;
        }
              parameters[6].Value =addrcgm;
              parameters[7].Value = txt_cdate.Text;
              parameters[8].Value = txt_address.Text;
              parameters[9].Value = txt_tel.Text;
              parameters[10].Value =Textarea1.Value;

        //提交到数据库
        DbHelperSQL.ExecuteSql(strSql.ToString(), parameters);

        MessageBox.ShowAndRedirect(this, "操作成功，请返回!", "Manage.aspx");
    }



    
}

