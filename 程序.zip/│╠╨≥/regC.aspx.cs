using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.Data;
using System.Data.SqlClient;


public partial class _Default  : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        
        if(!IsPostBack)
        {
             
            
        }
    }

    
    /// <summary>
    /// ע��
    /// </summary>
    protected void ButtonReg_Click(object sender, EventArgs e)
    {

        //��֤��ҵ����Ƿ��Ѿ�����
        if (DbHelperSQL.Exists("select count(*) from companys where lname = '" + txt_lname.Text + "' "))
        {
            MessageBox.Show(this, "���û����Ѵ��ڣ����������룡");
            return;
        }

         //����Sql
         StringBuilder strSql = new StringBuilder();
         strSql.Append(@"insert into companys ( lname,pass,cname,ctype,yg,cgm,cdate,address,tel,memo,regtime ) ");
        strSql.Append(@" values (@lname,@pass,@cname,@ctype,@yg,@cgm,@cdate,@address,@tel,@memo,@regtime)");

        //���ò���
        SqlParameter[] parameters = new SqlParameter[] {
            new SqlParameter("@lname", SqlDbType.VarChar,50),
            new SqlParameter("@pass", SqlDbType.VarChar,50),
            new SqlParameter("@cname", SqlDbType.VarChar,50),
            new SqlParameter("@ctype", SqlDbType.VarChar,50),
            new SqlParameter("@yg", SqlDbType.VarChar,50),
            new SqlParameter("@cgm", SqlDbType.VarChar,50),
            new SqlParameter("@cdate", SqlDbType.VarChar,50),
            new SqlParameter("@address", SqlDbType.VarChar,100),
            new SqlParameter("@tel", SqlDbType.VarChar,50),
            new SqlParameter("@memo", SqlDbType.NText,50000),
            new SqlParameter("@regtime", SqlDbType.DateTime,8)     };

        parameters[0].Value =txt_lname.Text;
        parameters[1].Value =txt_pass.Text;
        parameters[2].Value =txt_cname.Text;
        parameters[3].Value =txt_ctype.Text;
        parameters[4].Value =txt_yg.Text;
        string addrcgm ="";
        if (filecgm.HasFile)
        {
            string name = this.filecgm.PostedFile.FileName;
            int i = name.LastIndexOf('.');
            string extname = name.Substring(i);

            if (extname.ToLower() != ".jpg" && extname.ToLower() != ".png" && extname.ToLower() != ".gif")
            {
                MessageBox.Show(this, "���ϴ���ȷ��ʽ����ҵLogo��");
                return;
            }
            string filename = DateTime.Now.ToString("yyyyMMddhhmmssfff");
            string path = filename + extname;
            string savePath = Server.MapPath(@"uploads\" + filename + extname);
            filecgm.PostedFile.SaveAs(savePath);
            addrcgm = path;
        }
        else
        {
            MessageBox.Show(this, "���ϴ���ҵLogo��");
            return;
        }
        parameters[5].Value =addrcgm;
        parameters[6].Value =txt_cdate.Text;
        parameters[7].Value =txt_address.Text;
        parameters[8].Value =txt_tel.Text;
        parameters[9].Value =Textarea1.Value;
        parameters[10].Value = DateTime.Now;


        //�ύ�����ݿ�
        DbHelperSQL.ExecuteSql(strSql.ToString(), parameters);


        MessageBox.ShowAndRedirect(this, "��ϲ��ע��ɹ������¼��", "admin/login.aspx");
    }



    
    
}
