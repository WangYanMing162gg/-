using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.Data;
using System.Data.SqlClient;


public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            showInfo();
        }
    }

    protected void showInfo()
    {
        //�ж��Ƿ񴫵�id
        if (Request.QueryString["id"] != null)
        {
            //���ݱ�ŵõ���Ӧ�ļ�¼
            SqlDataReader sdr =
                DbHelperSQL.ExecuteReader("select  * from companys where cid=" + Request.QueryString["id"]);
            if (sdr.Read())
            {
                imgcgm.ImageUrl = "uploads/" + sdr["cgm"].ToString();
                lbcname.Text = sdr["cname"].ToString();
                lbctype.Text = sdr["ctype"].ToString();
                lbyg.Text = sdr["yg"].ToString();
                lbcdate.Text = sdr["cdate"].ToString();
                lbaddress.Text = sdr["address"].ToString();
                lbtel.Text = sdr["tel"].ToString();
                lbmemo.Text = sdr["memo"].ToString();


                GridView1.DataSource =
                    DbHelperSQL.Query(
                        "select top 10 a.*,b.cname from jobs a  left join companys b on a.cid=b.cid where  a.cid=" +
                        Request.QueryString["id"] + " order by jid desc");
                GridView1.DataBind();
            }
        }
    }
}