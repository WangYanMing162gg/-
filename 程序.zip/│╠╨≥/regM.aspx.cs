using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.Data;
using System.Data.SqlClient;


public partial class _Default  : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        
        if(!IsPostBack)
        {
             
            

            
            
            
        }
    }

    
    /// <summary>
    /// ע��
    /// </summary>
    protected void ButtonReg_Click(object sender, EventArgs e)
    {

        //��֤�û�����Ƿ��Ѿ�����
        if (DbHelperSQL.Exists("select count(*) from members where lname = '" + txt_lname.Text + "' "))
        {
            MessageBox.Show(this, "���û����Ѵ��ڣ����������룡");
            return;
        }

         //����Sql
         StringBuilder strSql = new StringBuilder();
         strSql.Append(@"insert into members ( lname,pwd,name1,sex,age,no1,tel,email,pic,regdate,flag ) ");
        strSql.Append(@" values (@lname,@pwd,@name1,@sex,@age,@no1,@tel,@email,@pic,@regdate,'��У')");

        //���ò���
        SqlParameter[] parameters = new SqlParameter[] {
            new SqlParameter("@lname", SqlDbType.VarChar,50),
            new SqlParameter("@pwd", SqlDbType.VarChar,30),
            new SqlParameter("@name1", SqlDbType.VarChar,50),
            new SqlParameter("@sex", SqlDbType.VarChar,50),
            new SqlParameter("@age", SqlDbType.VarChar,30),
            new SqlParameter("@no1", SqlDbType.VarChar,50),
            new SqlParameter("@tel", SqlDbType.VarChar,30),
            new SqlParameter("@email", SqlDbType.VarChar,100),
            new SqlParameter("@pic", SqlDbType.VarChar,50),
            new SqlParameter("@regdate", SqlDbType.DateTime,8)        };

        parameters[0].Value =txt_lname.Text;
        parameters[1].Value =txt_pwd.Text;
        parameters[2].Value =txt_name1.Text;
        parameters[3].Value =rtsex.SelectedValue;
        parameters[4].Value =txt_age.Text;
        parameters[5].Value =txt_no1.Text;
        parameters[6].Value =txt_tel.Text;
        parameters[7].Value =txt_email.Text;
        string addrpic ="";
        if (filepic.HasFile)
        {
            string name = this.filepic.PostedFile.FileName;
            int i = name.LastIndexOf('.');
            string extname = name.Substring(i);

            if (extname.ToLower() != ".jpg" && extname.ToLower() != ".png" && extname.ToLower() != ".gif")
            {
                MessageBox.Show(this, "���ϴ���ȷ��ʽ�ĸ�����Ƭ��");
                return;
            }
            string filename = DateTime.Now.ToString("yyyyMMddhhmmssfff");
            string path = filename + extname;
            string savePath = Server.MapPath(@"uploads\" + filename + extname);
            filepic.PostedFile.SaveAs(savePath);
            addrpic = path;
        }
        else
        {
            MessageBox.Show(this, "���ϴ�������Ƭ��");
            return;
        }
        parameters[8].Value =addrpic;
        parameters[9].Value = DateTime.Now;

        //�ύ�����ݿ�
        DbHelperSQL.ExecuteSql(strSql.ToString(), parameters);

     

        MessageBox.ShowAndRedirect(this, "��ϲ��ע��ɹ������¼��", "default.aspx");
    }



    
    
}
