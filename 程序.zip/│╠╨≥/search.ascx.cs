﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class search : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        if (keys.Text == "")
        {
            Page.ClientScript.RegisterStartupScript(this.GetType(), "alert", "<script>alert('关键字不能为空！');</script>");
            return;
        }

        Response.Redirect("~/job.aspx?k=" + Server.UrlEncode(keys.Text));
    }
}